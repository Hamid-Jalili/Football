// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Camera/CameraActor.h"
#include "TeleCameraActor.generated.h"

/**
 * 
 */
UCLASS()
class OSF_API ATeleCameraActor : public ACameraActor
{
	GENERATED_BODY()
	
	
	
	
};
